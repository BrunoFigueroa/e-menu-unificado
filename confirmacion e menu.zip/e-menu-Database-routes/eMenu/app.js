import express from "express";
import session from "express-session";
import bodyParser from "body-parser";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

const app = express();

// Para obtener __dirname con ESModules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configurar CORS para permitir peticiones desde el frontend
app.use(
  cors({
    origin: "http://localhost:3000", // Cambia si tu frontend usa otro puerto
    methods: "GET,POST,PUT,DELETE",
    credentials: true,
  })
);

// Middleware para parsear datos
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Configurar sesión
app.use(
  session({
    secret: "your-secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false },
  })
);

// Servir archivos estáticos desde 'webapp_inicio'
app.use(express.static(path.join(__dirname, "webapp_inicio")));

// Ruta para mostrar la página de confirmación
app.get("/confirmacion", (req, res) => {
  res.sendFile(path.join(__dirname, "webapp_inicio", "confirmacion.html"));
});

// Exportar la app para usarla en el archivo principal
export default app;
