//usé datos estáticos para el cálculo de tiempo, apenas se tengan datos o se descarte se modifica
//como estimación propia, hice que se suma el tiempo del plato más lento + la diferencia del segundo plato más lento
// además en caso de repetirse el mismo plato en un pedido, se cuenta el tiempo completo del primero y la mitad por cada unidad más, considerando que al elaborar lo mismo es menor
//esto es solo como ejemplo de función, ya que no es posible aplicarla en pedidos grandes o en casos donde se repitan mucho los platos.




function obtenerDuracionProducto(nombre) {
  const tiempos = {
    'Huevos con tostadas': 10,
    'Capuccino': 5,
    'Sándwich vegano': 12,
    'Ensalada César': 8,
    'Té verde': 4
    // datos estáticos ejemplo
  };
  return tiempos[nombre] || 5; // defecto 5 minutos si no está definido
}

function calcularTiempoEstimado(carrito) {
  const duraciones = carrito.map(producto => obtenerDuracionProducto(producto.nombre));

  if (duraciones.length === 0) return 0;
  if (duraciones.length === 1) return duraciones[0];

  duraciones.sort((a, b) => b - a);
  const [max1, max2] = duraciones;

  return max1 + (max1 - max2);
}

function mostrarResumenYTiempo() {
  const resumen = JSON.parse(localStorage.getItem('pedidoResumen'));
  const contenedor = document.getElementById('resumen-pedido');
  const tiempoContenedor = document.getElementById('tiempo-estimado');

  contenedor.innerHTML = '';
  tiempoContenedor.innerHTML = '';

  if (!resumen || !resumen.carrito || resumen.carrito.length === 0) {
    contenedor.innerHTML = '<p>No hay productos en el pedido.</p>';
    return;
  }

  const ul = document.createElement('ul');
  ul.className = 'list-group';

  resumen.carrito.forEach(producto => {
    const item = document.createElement('li');
    item.className = 'list-group-item d-flex justify-content-between';
    item.innerHTML = `<span>${producto.nombre} x${producto.cantidad}</span><span>$${(producto.precio * producto.cantidad).toLocaleString()}</span>`;
    ul.appendChild(item);
  });

  const totalItem = document.createElement('li');
  totalItem.className = 'list-group-item d-flex justify-content-between fw-bold';
  totalItem.innerHTML = `<span>Total</span><span>$${resumen.total.toLocaleString()}</span>`;
  ul.appendChild(totalItem);

  contenedor.appendChild(ul);

  const tiempoEstimado = calcularTiempoEstimado(resumen.carrito);
  tiempoContenedor.innerHTML = `<p class="mt-4 fw-bold text-info">⏳ Tiempo estimado de preparación: ${tiempoEstimado} minutos</p>`;
}

window.addEventListener('DOMContentLoaded', mostrarResumenYTiempo);
